---
name: Industrial B2B Design System
colors:
  surface: '#f7fafc'
  surface-dim: '#d7dadc'
  surface-bright: '#f7fafc'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f4f6'
  surface-container: '#ebeef0'
  surface-container-high: '#e5e9eb'
  surface-container-highest: '#e0e3e5'
  on-surface: '#181c1e'
  on-surface-variant: '#43474e'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eef1f3'
  outline: '#74777f'
  outline-variant: '#c4c6cf'
  surface-tint: '#455f88'
  primary: '#002045'
  on-primary: '#ffffff'
  primary-container: '#1a365d'
  on-primary-container: '#86a0cd'
  inverse-primary: '#adc7f7'
  secondary: '#944b00'
  on-secondary: '#ffffff'
  secondary-container: '#fe9743'
  on-secondary-container: '#6b3500'
  tertiary: '#002141'
  on-tertiary: '#ffffff'
  tertiary-container: '#003765'
  on-tertiary-container: '#68a2e9'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e3ff'
  primary-fixed-dim: '#adc7f7'
  on-primary-fixed: '#001b3c'
  on-primary-fixed-variant: '#2d476f'
  secondary-fixed: '#ffdcc5'
  secondary-fixed-dim: '#ffb783'
  on-secondary-fixed: '#301400'
  on-secondary-fixed-variant: '#703700'
  tertiary-fixed: '#d3e4ff'
  tertiary-fixed-dim: '#a2c9ff'
  on-tertiary-fixed: '#001c38'
  on-tertiary-fixed-variant: '#004881'
  background: '#f7fafc'
  on-background: '#181c1e'
  surface-variant: '#e0e3e5'
typography:
  headline-xl:
    fontFamily: Manrope
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Manrope
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1'
  headline-lg-mobile:
    fontFamily: Manrope
    fontSize: 28px
    fontWeight: '700'
    lineHeight: '1.2'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
  stack-sm: 12px
  stack-md: 24px
  stack-lg: 48px
---

## Brand & Style
The design system is engineered for the high-stakes world of industrial and electrical procurement. It prioritizes **functional minimalism**—a style that balances the raw utility of heavy industry with the polished efficiency of modern enterprise software. The visual language conveys reliability, precision, and institutional trust.

The aesthetic utilizes expansive whitespace to reduce cognitive load during complex ordering processes. It leans into a **Corporate / Modern** aesthetic, utilizing high-quality typography and a disciplined color application to guide users through dense technical specifications and multi-line catalogs without friction. The emotional response is one of "effortless control."

## Colors
The palette is rooted in a **Deep Corporate Blue**, signifying stability and established authority. This is the primary driver for navigation, headers, and structural elements. 

**Bright Orange** is reserved strictly for high-priority Call to Action (CTA) elements, hover states, and critical alerts. Its high contrast against the blue and white ensures that the "Order" or "Add to Quote" actions are never missed. 

We use a layered neutral system: 
- **Pure White (#FFFFFF)** for primary content surfaces and cards.
- **Light Gray (#F7FAFC)** for background sectioning to create subtle visual separation between content blocks.
- **Cool Grays** for borders and secondary metadata.

## Typography
The typography system is built for clarity and technical density. **Manrope** is used for all headlines; its modern, slightly geometric character provides a sophisticated, "engineered" look. **Inter** is the workhorse for body text and UI labels, chosen for its exceptional legibility at small sizes and its comprehensive Cyrillic support, which is vital for international technical documentation.

Key Rules:
- Use `headline-xl` only for main landing hero sections.
- `label-md` should be used for table headers and category tags to differentiate them from interactive text.
- Line heights are generous (1.6x for body) to ensure readability when viewing long lists of electrical specifications.

## Layout & Spacing
This design system utilizes a **12-column fluid grid** for desktop and a single-column flow for mobile. The layout philosophy centers on "The Power of the Grid"—aligning every element to a strict 8px baseline.

- **Desktop (1280px+):** 40px outer margins, 24px gutters. Use content-heavy layouts where technical specs can sit side-by-side with imagery.
- **Tablet (768px - 1024px):** 24px outer margins, 16px gutters.
- **Mobile (<768px):** 16px margins. Complex tables should transition to card-based views for readability.

Spacing follows a "Stack" model: use `stack-md` for separating logical sections within a page and `stack-sm` for elements within a component (like a label above an input).

## Elevation & Depth
To maintain a minimalist B2B feel, the design system avoids heavy shadows. Instead, it uses **Tonal Layering** combined with **Ambient Shadows**.

- **Level 0 (Base):** Light Gray (#F7FAFC) background.
- **Level 1 (Surfaces):** Pure White (#FFFFFF) cards and containers with a subtle 1px border (#E2E8F0).
- **Level 2 (Interactive):** Elements like product cards or active inputs use a soft, diffused shadow (0px 4px 20px rgba(26, 54, 93, 0.05)) to suggest "lift."
- **Level 3 (Overlays):** Modals and dropdowns use a more pronounced shadow (0px 10px 30px rgba(0, 0, 0, 0.1)) to focus user attention.

Hover states on interactive cards should subtly increase the shadow spread rather than changing the background color, maintaining a clean, high-end feel.

## Shapes
The shape language is "Approachable Industrial." While the industry is often associated with sharp edges and steel, the UI uses **Rounded (Level 2)** shapes to feel modern and user-friendly.

- **Standard Elements:** 0.5rem (8px) for buttons and inputs.
- **Large Elements:** 1rem (16px) for product cards and main content containers.
- **Extra Large:** 1.5rem (24px) for hero banners or promotional tiles.

This softening of the UI creates a "Sleek Tech" vibe that differentiates the platform from legacy industrial software.

## Components

### Buttons
- **Primary:** Deep Blue background, white text. Transitions to a slightly lighter blue on hover.
- **CTA:** Bright Orange background, white text. This is used for "Buy Now" or "Submit Order."
- **Secondary/Ghost:** Transparent background with a 1.5px Deep Blue border.

### Input Fields
- High-contrast 1px borders (#CBD5E0). On focus, the border transitions to Deep Blue with a soft 2px outer glow.
- Labels sit above the field in `label-sm` with a medium-gray color.

### Product Cards
- White background, 1px subtle border, `rounded-lg` (1rem).
- Product images should have a very light gray background to ensure white equipment doesn't "bleed" into the card.
- Pricing is highlighted in Deep Blue, Bold.

### Chips & Status Indicators
- Used for "In Stock" (Green tint), "Out of Stock" (Red tint), or "Backordered" (Orange tint). 
- Shapes are fully pill-shaped (rounded-full) for immediate recognition.

### Data Tables
- Vital for B2B. Use clean, borderless rows with subtle zebra striping (#F7FAFC). 
- Header text is `label-md` for maximum clarity.